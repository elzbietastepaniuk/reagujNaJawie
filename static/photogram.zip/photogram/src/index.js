import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";


// Metoda ReactDOM.createRoot() tworzy kontener aplikacji React, który jest używany do renderowania aplikacji do elementu docelowego w drzewie DOM. Kontener aplikacji jest renderowany do elementu o identyfikatorze "root" w pliku HTML.
const root = ReactDOM.createRoot(document.getElementById("root"));

// Komponent React.StrictMode jest używany w celu wykrywania potencjalnych problemów w aplikacji i ostrzegania o nich w konsoli przeglądarki.
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
