import React from 'react';


// Komponent App jest głównym komponentem aplikacji, który renderuje całą aplikację.Wewnątrz tego komponentu znajduje się główny sekcja komentarzy, reprezentowana przez komponent CommentSection.
function App() {

  // Deklaracja stałej użytkownika (symulacja logowania) - obiekt zawierający (nickname i avatar) 
  const user = {
    nickname: 'alina_malina',
    avatar: '/images/avatars/av3.jpg'
  };
  

  return (
    <div className="App">
      <h2>Tu powstanie aplikacja React</h2>
    </div>
  );
} 

export default App;
